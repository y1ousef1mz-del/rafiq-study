plugins { id("com.android.application") }
android {
 namespace = "com.rafiqstudy.app"
 compileSdk = 36
 defaultConfig { applicationId = "com.rafiqstudy.app"; minSdk = 24; targetSdk = 36; versionCode = 6; versionName = "4.0-preview" }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
}
