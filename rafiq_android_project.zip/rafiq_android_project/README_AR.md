# رفيق الدراسة V3 — مشروع جديد مستقل
واجهة عربية تعمل دون اتصال للجدول والمهام والمؤقت والحاسبة. روابط يوتيوب تحتاج إنترنت. ليست خدمة ذكاء اصطناعي حقيقية ولا بنك أسئلة وزارية موثق. البيانات تحفظ محليًا في WebView. لم يُختبر بناء APK في هذه البيئة.
## بناء التطبيق
ارفع محتويات هذا المجلد إلى مستودع جديد على GitHub (وليس ZIP داخل المستودع). افتح Actions وشغّل Build Rafiq V3 APK ثم نزّل artifact. أو افتحه في Android Studio مع JDK 17 وGradle 8.9.
## تنبيه التحديث
applicationId هو com.rafiqstudy.app لكن النسخة القديمة قد تكون موقعة بمفتاح مختلف، لذلك قد تحتاج إزالة النسخة القديمة بعد حفظ بياناتك؛ لا يوجد ترحيل تلقائي للبيانات. لا تنشر نسخة debug على Google Play؛ تحتاج توقيع release ومراجعة سياسات المتجر.


## V3.1 preview
- Fixed bottom navigation; icon and success-stairs illustration.
- Ministerial exams section is an empty sourced-content template, with a clearly marked training sample.
- Universities section saves a user-entered choice locally; no verified nationwide catalog included yet.
- First-ten free subscription is an informational preview only: production requires server-side atomic enrollment, authentication, and billing.
- Debug APK signing can differ across GitHub builds: do not uninstall an app containing important data without backup.
