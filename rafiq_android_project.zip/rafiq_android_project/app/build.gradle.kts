plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.rafiqstudy.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.rafiqstudy.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }
}

dependencies {
    implementation("com.google.android.gms:play-services-ads:23.6.0")
}
