plugins { id("com.android.application") }
android {
 namespace = "com.rafiqstudy.app"
 compileSdk = 35
 defaultConfig { applicationId = "com.rafiqstudy.app"; minSdk = 24; targetSdk = 35; versionCode = 5; versionName = "3.1-preview" }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
}
